import pygame
import openpyxl
from pygame.locals import *
import datetime
import time
import math

# モード
mode = 0  # 0メニュー画面　#1出題
mode2 = 1  # 0:全問題特訓　1:100個厳選モード
sort_mode = 1  # 1:出題が時系列順にソートされる

# マルチモード用
multi_mode = False
bookId = None
mode2is3 = None

# ウィンドウ
pygame.init()
screen = pygame.display.set_mode((1200, 800))
pygame.display.set_caption("漢字テスト")

# ファイル
book = -1
file = ["yoji-kaki.xlsx", "kojikoto.xlsx", "onyomi.xlsx", "kunyomi.xlsx",
        "onkun.xlsx",
        "example.xlsx",
        "kunyomi_reading.xlsx", "onyomi.xlsx", "onyomi.xlsx", "kokuji.xlsx"]

###ボタン機能
button = pygame.Rect(405, 420, 100, 60)
butt_wrong = pygame.Rect(592, 420, 100, 60)
butt_through = pygame.Rect(768, 420, 100, 60)

# テキストボックスの初期設定
input_box = pygame.Rect(50, 300, 140, 32)
color_inactive = pygame.Color("lightskyblue3")
color_active = pygame.Color("dodgerblue2")
ipbox_color = color_inactive
ipbox_active = False
ipbox_text = "book(2),mode2(3),d0(1),cycle(0)"
ipbox_text = ""
inquiry_command = ["dint", "book", "st-ed", "mode2", "d0", "cycle"]
# mode2(3),d0(0):各dint[0]の問題数ぶんのみを収集する

# 科目選択
butt_local = [[550, 350], [550, 450], [550, 550], [550, 650], [700, 350], [100, 200], [700, 450], [700, 550],
              [700, 650], [850, 350]]
butt_color = [[250, 250, 150], [250, 150, 150], [0, 150, 150], [100, 100, 250], [50, 255, 50], [0, 100, 140],
              [255, 20, 147], [0, 150, 150], [0, 150, 150], [125, 125, 125]]
butt_subject = []
for i in butt_local:
    butt_subject.append(pygame.Rect(i[0], i[1], 100, 60))

butt_100tokkun = pygame.Rect(100, 100, 100, 60)
butt_0limited = pygame.Rect(250, 100, 100, 60)

font = pygame.font.SysFont("hgs明朝e", 25)
text = font.render("進む", True, (0, 0, 0))
text_wrong = font.render("不正解", True, (0, 0, 0))
text_through = font.render("スルー", True, (0, 0, 0))

text_name = ["0四字熟語", "1故事成語", "2音読み", "3訓読み", "4音訓", "5テスト", "6訓読み(読み)", "7音読み2", "8音読み3", "9国字"]
text_local = butt_local
text_subject = []
for i in text_name:
    text_subject.append(font.render(i, True, (0, 0, 0)))

text_100tokkun = font.render("モード変更", True, (0, 0, 0))
text_0limited = font.render("0問True", True, (0, 0, 0))

# パッチ
patch_minus = [0, 0, 0, 0, 0, 0, 0, 1500, 3000, 0]

# 漢字取り出し
cnt = 0
r = 0  # 開始問題 ##########################################################0が一問目
c = 0
n_over = 0  # 累計問題数が、これより大きいなら出題しない
n_timer = 0  # 前回からの正解経過日数がこれ以下なら出題しない -1なら無し
start_r = [10, 12, 11, 10, 2, 2, 10, 1511, 3011, 9]  # Row 行
start_c = [3, 3, 5, 3, 3, 2, 3, 5, 5, 3]  # Column 列
q_type = [[1, 3, 4, 6, 7, -1], [None, 2, 3, 4, 6, -1], [None, -2, 1, 2, 3, -3], [None, 2, None, 3, 4, -1],
          [1, 1, None, 4, 5, -1],
          [None, 2, 3, 4, 5, -1],
          [None, 2, None, 3, 4, -1], [None, -2, 1, 2, 3, -3], [None, -2, 1, 2, 3, -3],
          [None, 2, 3, 4, 5, -1]]  # 読み、解答、別答、意味、ポイント,問題番号
dq_pattern = [3, 0, 1, 0, 2, 0, 0, 1, 1, 1]  # 出題時の遷移パターン

ques_no = 0  # 問題番号
great = 0  # 正解数
cumul = 1  # 累計問題数
steat = 0  # 状態 0:出題　1:読み表示　2:答えと解説表示

play_time = datetime.datetime.now()  # 起動時の日付時間

day_interval = [-1, 2, 7, 14, 30]  # 0正解→常に出題　1正解3日　2正解7日　3正解14日　4以上正解30日
compb_list = [[] for _ in range(5)]  # 出題に適合する
compb_list2 = [[] for _ in range(5)]
compb_list3 = [[] for _ in range(5)]
compb_multi = []

# セクション別問題数
# (デフォルト29 +1)
sectionwise=[[9,9,9,9,9] for _ in range(10)]


# アタックモード用
repeat_list = []
repeat_1 = 0
seikai_su = 0
zero_limited = False  # 累積正解数が0問の問題のみ出題する=True

# 読み込み用
letter = []  # 問題番号、読み、解答、別答、意味、ポイント
mondai_su = 0
m_num = 0

# cycleモード用
cycle = 20  # 区切る数
cyclePin = 0  # cycleの場所
cyclePinSub = 0  # 各cycleのどの位置にいるか
cycleNum = 0  # サイクルの総数
cycleList = []  # 問題リストcL
cycleCorrectNum = 0  # サイクル内での正解数
cycleCorrectRatio = 0.6  # 脱出基準正解率

# 統計
# 正解数を調べる
point_volume = [0, 0, 0, 0, 0, 0]
mondai_volume = [1605, 2390, 1500, 648, 7000, 33, 1399, 1500, 1200, 125]
# book=2は1500だけど1300
# book=3は1399だけど648
strtg_point = []  # 各問題のポイント
point_time = []  # 各問題のタイム(day)
first_question = []  # まだ出題されたことがないならTrue


# 各問題が得点をいくつもっているかファイル参照する timeも参照する
def point_check():
    global compb_list2  # globalで宣言しないと、リストの初期化で関数内で再定義されてしまう
    compb_list2 = [[] for _ in range(5)]  # リストの初期化
    for i in range(mondai_volume[book]):

        # ポイントチェック
        point = ws.cell(start_r[book] + i, start_c[book] + q_type[book][4]).value
        point = 0 if point == None else int(point)
        strtg_point.append(point)
        if point <= 4:
            point_volume[point] += 1
        else:
            point_volume[5] += 1
        # タイムチェック
        p_time = ws.cell(start_r[book] + i, start_c[book] + q_type[book][4] + 1).value
        day_i = 0  # この問題の経過日数
        if p_time == None:
            if point > 0:  # ポイントが1以上なのに、何らかの理由でタイムスタンプが出来ていない場合
                point_time.append(365)  # 365日経過とする
                day_i = 365
            else:
                point_time.append(0)
                first_question.append(True)
                day_i = 0
        else:
            point_time.append((play_time - p_time).days)
            first_question.append(False)
            day_i = (play_time - p_time).days

        # mode2==1用　適合リストに入れていく
        point = 4 if point >= 4 else point  # 4点以上は全て4点にまるめる
        if day_interval[point] <= day_i:  # 指標経過日数>経過日数なら
            compb_list[point].append(i)  # 問題番号,経過日数　格納
            # point=0のとき、dai_iが0になり、このとき-1<=0が常に成り立つ
            compb_list2[point].append([day_i, i])

        # compb_list3 統計データ閲覧用
        compb_list3[point].append([day_i, i])

    # print("compb_list2 in point_check()")
    print(compb_list2)


def n_check3(r, mondai_su, book=None, under_mondai=None):
    if ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][5]).value == None:  # 問題がこれ以上ない
        return mondai_su
    yomikomi_flg = True

    # タイムチェック
    p_time = ws.cell(start_r[book] + r, start_c[book] + q_type[book][4] + 1).value
    dy_i = 0  # この問題の経過日数
    if p_time == None:
        dy_i = 0
    else:
        dy_i = (play_time - p_time).days

    # mode2=2　アタック用
    yomikomi_flg = True
    poin = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][4]).value

    if under_mondai != None:
        if poin != None and poin > under_mondai:
            # 正答数が大きい（poinがunder_mondaiを超える）場合は入れない
            yomikomi_flg = False

    mnom = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][5]).value
    mdai = ws.cell(start_r[book] + r, start_c[book] + c).value
    yomi = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][0]).value if q_type[book][0] != None else 0
    ktou = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][1]).value
    btou = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][2]).value if q_type[book][2] != None else ""
    mean = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][3]).value
    # poin = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][4]).value
    best = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][4] + 2).value  # Noneの場合がある

    if book == 4:  # 音訓モードの特殊表示
        yomi_on = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][0]).value
        yomi_kun = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][0] + 1).value
        yomi_okuri = ws.cell(start_r[book] + r, start_c[book] + c + q_type[book][0] + 2).value
        yomi_on = yomi_on.split("・") if yomi_on != None else [""]
        yomi_kun = yomi_kun.split("・") if yomi_kun != None else [""]
        yomi_okuri = yomi_okuri.split("・") if yomi_okuri != None else [""]
        yomi = [yomi_on, yomi_kun, yomi_okuri]

    # mode2=3 d0=1 未着手の問題には手を付けないモード
    # print(message[4])
    if message[4] == [1]:
        if poin == None:
            # print(mnom,mdai)
            yomikomi_flg = False

    # 読み込んでヨシ！
    if yomikomi_flg == True:
        letter.append([mnom, mdai, yomi, ktou, btou, mean, poin, best, dy_i, book])
        mondai_su += 1
        '''
        print("■■■■■■")
        print(mondai_su)
        print("0問題番号",mnom, "1問題",mdai,"2読み", yomi,"3解答" ,ktou, "4別答",btou, "5解説",mean, "6正答数",poin, "7累計正答",best, "8経過日数",dy_i)
        '''

    return mondai_su


def kaisetsu_display(kaisetsu_read,turn=None,x=None,y=None,size=None):
    # 解説表示
    if turn==None:
        turn=30
    if kaisetsu_read != None:  # 解説がない場合はスルー
        kaisetsu = length_turn(kaisetsu_read, turn)
        if x==None and y==None and size==None:
            for i in range(len(kaisetsu)):
                text_display(kaisetsu[i], 173, 514 + i * 25, 20)
        else:
            for i in range(len(kaisetsu)):
                text_display(kaisetsu[i], x, y + i * size, size)


################テキストボックス領域#############################################
message = [[] for _ in range(len(inquiry_command))]


def textbox():
    # テキストボックスの描画
    if ipbox_active:
        ipbox_color = color_active
    else:
        ipbox_color = color_inactive
    pygame.draw.rect(screen, ipbox_color, input_box, 2)

    # テキストの表示
    text_display(ipbox_text, input_box.x + 5, input_box.y + 5, 20)


# 各コマンドの内容をコンマで区切って配列の形にして差し戻す
def command_dividing(text, cmd, message):
    if text in cmd:
        st = cmd.find(str(text) + "(")
        ed = cmd.find(")")
        sep_message = cmd[st + len(text) + 1:ed]
        new_message = sep_message.split(",")
        # 各要素が数値なら、文字列を数値に変換
        for i in range(len(new_message)):
            if new_message[i].isdecimal():
                new_message[i] = int(new_message[i])

        return new_message
    else:
        return message


# テキストボックスの内容を、),または最後の)ごとに区切る
def text_analysis(text):
    commands = []
    sep_index = 0
    for i in range(0, len(text) - 1):
        if (text[i] == ")" and text[i + 1] == ","):
            commands.append(text[sep_index:i + 1])
            sep_index = i + 2
        # カッコが最後の時、カッコまで含める(i+2まで)
        elif (i + 1 == len(text) - 1 and text[i + 1] == ")"):
            commands.append(text[sep_index:i + 2])
            sep_index = i + 1

    # 区切ったあと、特定のコマンド day_interval(1,2,3)など、の形を検出し、1,2,3を取り出す
    for i in range(len(commands)):
        cmd = commands[i]
        # inquiry_command=["day_interval","book","st-ed","mode2"]
        # messageの大きさは5に対し、inquiry_commandは（現状）4のため、inquiry_commandが増えるときは
        # messageの大きさを拡張する必要がある　また、サイズに関わる変数は同一のものを使うべきだ
        for j in range(len(inquiry_command)):
            message[j] = command_dividing(inquiry_command[j], cmd, message[j])
            '''
            上記のコードは、値の内容が変わらないときに備えて、message[i]を引数として渡し、
            変わらないときは返り値をmessage[i] (すなわちmessage[i]=message[i])としているが、
            pythonでは値は常に参照渡しなので、関数内で直接配列にアクセスして値を変更して問題ない
            '''
    return message


# ■ディスプレイ問題処理領域#########################################################################3

def display_question(state, m_num, book):
    # トラップ　仮変数でもってる変数はstateだが、
    # 外側で引数として渡されるのはsteat

    state = state % 3
    ptn = dq_pattern[book]
    letr = letter[m_num][1]  # 出題
    kanzi_read = letter[m_num][2]  # 読み
    kanzi_kaki = letter[m_num][3]  # 書き（答え）
    kanzi_bettou = letter[m_num][4]  # 別答
    kaisetsu_read = letter[m_num][5]  # 解説

    if state in [0, 1]:
        if ptn == 3:  # ptn=3 四字熟語の出題
            text_display(letr, 50, 100, 200)

    if state in [0, 1, 2]:
        if ptn == 0 or ptn == 1:  # ptn=0,1 折り返し出題部分
            shutsudai = length_turn(letr, 20)
            for i in range(len(shutsudai)):
                text_display(shutsudai[i], 50, 100 + i * 50, 50)
        elif ptn == 2:  # ptn=2 音訓出題
            h_size = 200
            # 例外の場合フォントサイズを変える
            if len(letr) > 1:
                # 1.表示できない場合・（へんつくり）
                # 2.読み一覧モード　（Yからはじまる）
                h_size = 50
            text_display(letr, 50, 100, h_size)

    if state in [2]:
        if ptn == 0:  # ptn=0 解説・答え
            # フォントの大きさ
            kaki_fontsize = 150
            kaki_fontsize = 75 if book == 6 else 150
            text_display(kanzi_kaki, 200, 225, kaki_fontsize, (255, 0, 0))
            text_display(kanzi_bettou, 600, 305, 60, (255, 0, 0))

            # 解説表示
            kaisetsu_display(kaisetsu_read)

        elif ptn == 1:  # ptn=1 答え
            # フォントの大きさ
            kaki_fontsize = 150
            kaki_fontsize = 75 if book == 6 else 150
            text_display(kanzi_kaki, 200, 225, kaki_fontsize, (255, 0, 0))
            text_display(kanzi_bettou, 600, 305, 60, (255, 0, 0))

        elif ptn == 2:  # ptn=2 音訓の答え
            for ix in range(3):
                for jx in range(len(kanzi_read[ix])):
                    text_display(kanzi_read[ix][jx], 300 + 200 * ix, 170 + 70 * jx, 40, (255, 0, 0))
            kaisetsu_display(kaisetsu_read)

        elif ptn == 3:  # ptn=3 四字熟語の出題（アンダースコア消去）答え・解説
            k_kaki_x = 50

            # 四字熟語モードに限り、空欄に赤字で答えを表示する
            if letr[0] == "_":
                letr = "    " + letr[4:6]
            else:
                letr = letr[0:2]
                k_kaki_x = 450
            text_display(letr, 50, 100, 200)
            text_display(kanzi_kaki, k_kaki_x, 100, 200, (255, 0, 0))
            text_display(kanzi_bettou, 914, 40, 40, (255, 0, 0))

            # 解説表示
            kaisetsu_display(kaisetsu_read)

    if state in [1, 2]:
        if ptn == 1:  # ptn=1 解説部分
            # 解説表示
            kaisetsu_display(kaisetsu_read)
        elif ptn == 3:  # ptn=3 四字熟語の読みヒント
            text_display(kanzi_read, 412, 331, 25)

    if state in [1]:
        if ptn == 2:  # 音訓の外殻
            kanzi_read = []
            kanzi_read.append(letter[m_num][2][0])  # 音読み　["セイ","ショウ"]
            kanzi_read.append(letter[m_num][2][1])  # 訓読み　["なま","いのち","うぶ","き"]
            kanzi_read.append(letter[m_num][2][2])  # 送り仮名　["いーきる","うーまれる","うーむ","おーう","はーえる","なーる"]

            for ix in range(3):
                hyouzi_su = 0
                if kanzi_read[ix][0] == '':  # 情報が空欄の場合0
                    hyouzi_su = 0
                else:
                    hyouzi_su = len(kanzi_read[ix])
                text_display(str(hyouzi_su), 300 + 200 * ix, 100, 50)
                if ix == 2:
                    if kanzi_read[2][0] == '':  # 送り仮名の情報がない場合はbreak
                        break

                    # 送り仮名変換システム
                    for jx in range(len(kanzi_read[ix])):  # "いーきる"
                        gokan = letr  # 語幹　生
                        katsuyougobi = kanzi_read[ix][jx].split("ー")  # 活用語尾　["い","きる]
                        okurigana = gokan + katsuyougobi[1]  # 送り仮名　生+きる
                        text_display(okurigana, 300 + 200 * ix, 170 + 70 * jx, 50)


# テキスト表示　(テキスト内容、x,y,フォントサイズ,(R,G,B)) RGBは省略可　デフォルトで黒文字
def text_display(text, x, y, f, c=(0, 0, 0)):
    font_this = pygame.font.SysFont("hgs明朝e", f)
    ques_no_mess = font_this.render(text, True, c)
    screen.blit(ques_no_mess, (x, y))


# Excelファイルの読み込み
def reading_file(filename):
    print(filename)
    wb = openpyxl.load_workbook(filename)
    ws = wb.worksheets[0]
    return wb, ws


# 長いstringを折り返して表示する(text,一行の長さ)
def length_turn(kaisetsu_read, turn):
    l_cnt = 0
    r_cnt = 0
    kaisetsu = []
    list_kaisetsu_read = list(kaisetsu_read)

    while True:
        if list_kaisetsu_read[r_cnt] == "\n" or r_cnt - l_cnt > turn:
            if list_kaisetsu_read[r_cnt]=="\n":
                kaisetsu.append(kaisetsu_read[l_cnt:r_cnt])
                #実装予定　改行コードを消す
            else:
                kaisetsu.append(kaisetsu_read[l_cnt:r_cnt])
            l_cnt = r_cnt
        r_cnt += 1
        if r_cnt >= len(kaisetsu_read):
            kaisetsu.append(kaisetsu_read[l_cnt:r_cnt])
            break
    return kaisetsu


def point_coloring(point):
    point_c = (0, 0, 0)
    if point == None:
        return point_c

    if point == 1:
        point_c = (0, 0, 255)
    elif point == 2:
        point_c = (0, 255, 0)
    elif point == 3:
        point_c = (255, 0, 0)
    elif point > 3:
        point_c = (0, 255, 255)
    return point_c


def cycle_mode_initialize():
    # 初期化
    global cyclePin, cyclePinSub, cycleCorrectNum
    leftMondai_su = repeat_list.count(0)  # 残り問題数
    unansweredGroup = []  # まだ正解していない群(問題0番号)
    for i_cy in range(mondai_su):
        if repeat_list[i_cy] == 0:
            unansweredGroup.append(i_cy)

    cycleNum = math.ceil(leftMondai_su / cycle)  # サイクルの総数（切り上げ）
    cycleList = [[] for _ in range(cycleNum)]  # 問題リスト(cL)
    # 問題の割り振り
    for i_cy in range(leftMondai_su):
        cycleList[int(i_cy / cycle)].append(unansweredGroup[i_cy])
    print(cycleList)

    cyclePin = 0
    cyclePinSub = 0
    cycleCorrectNum = 0

    return cycleList


# あるサイクル内で、問題を[解いていない場所]まで進める
# 最後まで進めたときに配列を一つはみでる状態
def cycle_question_skip():
    global m_num, cyclePinSub

    while True:
        cyclePinSub += 1
        # 配列外に到達→脱出
        if len(cycleList[cyclePin]) == cyclePinSub:
            break

        m_num = cycleList[cyclePin][cyclePinSub]
        # 正解済み問題はスルー
        if repeat_list[m_num] == 0:
            break


# メインループ
running = True
while running:
    screen.fill((255, 255, 255))

    if mode == 0:
        ###スタート画面
        # ボタン・テキスト表示
        for i in range(len(butt_subject)):
            if i!=5:
                pygame.draw.rect(screen, (butt_color[i][0], butt_color[i][1], butt_color[i][2]), butt_subject[i])
                screen.blit(text_subject[i], (text_local[i][0], text_local[i][1]))

        pygame.draw.rect(screen, (0, 250, 150), butt_100tokkun)
        screen.blit(text_100tokkun, (100, 100))


        # テキストボックス表示
        textbox()
        next_command = text_analysis(ipbox_text)

        #遊び方
        textHowToPlay="下の科目をクリックして問題を進めよう"
        text_display(textHowToPlay,430,300,30)

        #モード説明
        mode_explain=""
        mode_explain2=""
        if mode2==1:
            mode_explain="通常モード"
            mode_explain2="累計正解数ごとに出題間隔を空けます。\r\n" \
                          "１問正解:2日、2問正解:7日、3問正解:14日、4問以上正解:30日\r\n" \
                          "問題が終わるか、ウィンドウを閉じるとそのまま保存されます"
        elif mode2==2:
            mode_explain="特訓モード　出題問題指定"
            mode_explain2="条件に当てはまる問題を無限に出題し続けます。1周すると、正解していない問題をまた出題し続けます\r\n" \
                          "テキストボックス領域に「st-ed(最初の問題番号,最後の問題番号)」と入力すると問題領域を指定できます\r\n" \
                          "例:st-ed(130,150) :130番から150番まで出題\r\n" \
                          "問題が終わったら自動終了します。保存はされません"

        elif mode2==3:
            mode_explain="特訓モード　累計0問指定"
            mode_explain2="条件に当てはまる問題を無限に出題し続けます、1周すると、正解していない問題をまた出題し続けます\r\n" \
                          "現時点で正解していない問題を出題します\r\n" \
                          "問題が終わったら自動終了します。保存はされません"
        text_display(mode_explain,42,35,35)
        kaisetsu_display(mode_explain2,40,380,100,20)



    elif mode == 1:
        # ボタン・テキスト表示
        pygame.draw.rect(screen,(250,250,150),(405,420,140,60))
        pygame.draw.rect(screen,(250,150,150),(592,420,140,60))
        pygame.draw.rect(screen,(150,240,240),(768,420,140,60))
        text_display("正解:",405,420,20)
        text_display("エンターキー",405,440,20)
        text_display("Zキー",405,460,20)
        text_display("不正解:",592,420,20)
        text_display("バックスペース",592,440,20)
        text_display("Aキー",592,460,20)
        text_display("スルー:",768,420,20)
        text_display("その他のキー",768,440,20)

        ###### 出題
        ##共通部分

        # テスト表示項目
        if message[5] == [0]:
            cycleRatio = str(str(cyclePin) + "/" + str(len(cycleList) - 1))
            text_display(f"cP:{cycleRatio}", 600, 85, 30)
            text_display(f"cPS:{cyclePinSub}", 750, 85, 30)
            text_display(f"cPC:{cycleCorrectNum}", 870, 85, 30)

        # 問題番号
        ques_num = letter[m_num][0]
        text_display(f"{ques_num}", 42, 35, 35)

        # この問題の正答数
        point = letter[m_num][6]
        point = 0 if point == None else int(point)
        point_c = point_coloring(point)
        text_display(f"累計正答数: {point}", 200, 35, 35, point_c)
        best_point = letter[m_num][7]
        point_c = point_coloring(best_point)
        text_display(f"最高正答数: {best_point}", 500, 35, 35, point_c)

        if mode2 == 2 or mode2 == 3:  # アタックモード　現在の表示される問題
            text_display(f"累積:{seikai_su}", 1000, 370, 20)
            text_display(f"進捗:{round(100 * seikai_su / mondai_su, 2)}%", 1000, 390, 20)

        str_x = 1000
        str_y = 400
        # カウント
        ques_no = r + 1
        text_display(f"問題数: {ques_no}", str_x, str_y + 15, 15)
        # 正答数
        if mode2 == 0:
            text_display(f"正答: {str(great) + '/' + str(cumul)}", str_x, str_y, 15)
        elif mode2 == 1:
            text_display(f"正答: {str(great) + '/' + str(cumul) + '/' + str(mondai_su)}", str_x, str_y, 15)
        # 経過日数表示
        keika_day = letter[m_num][8]
        text_display(f"{keika_day}日", str_x, str_y + 30, 15)

        # 統計
        for i in range(6):
            if i < 5:
                text_display("  " + str(i) + f"点: {str(point_volume[i])}", str_x, str_y + 45 + i * 15, 15)
            else:
                text_display(f"5点上: {str(point_volume[i])}", str_x, str_y + 45 + i * 15, 15)

        #遊び方
        textHowToPlay="任意のキーを押すと問題のヒントや解答に進みます"
        textHowToPlay2="赤字の解答が表示されたら、正解・不正解・スルーをキーを押して選んでね"
        text_display(textHowToPlay,20,380,15)
        text_display(textHowToPlay2,20,400,15)

        # state固有部分
        # 問題文表示
        display_question(steat, m_num, letter[m_num][9])



    elif mode==2:
        saved=""
        if mode2==1:
            saved="成績が保存され、次回の復習日数が決定します"
        text_display("お疲れさまでした！",200,100,50)
        text_display("問題は終了です",200,200,50)
        text_display("×ボタンを押してください",200,300,50)
        text_display(saved,200,500,30)


    ############################################################################################
    # ボタンダウン処理
    wrong_key = False
    throug_key = False
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            # ファイル終了
            wb.save(file[book])
            wb.close()
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            if mode == 0:
                # テキストボックス領域　マウスが領域内でクリックされた
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if input_box.collidepoint(event.pos):
                        ipbox_active = not ipbox_active
                    else:
                        ipbox_active = False

                # マルチモード確認
                mode2is3 = message[3]
                bookId = message[1]
                print(bookId)
                if mode2is3 != None:
                    if mode2is3 == [3]:
                        multi_mode = True
                        mode2 = 3

                ###最初の読み込み
                for i in range(len(butt_subject)):
                    # 特定の科目ボタンがクリックされた
                    if butt_subject[i].collidepoint(event.pos):
                        mode += 1
                        if multi_mode == False:
                            bookId = [i]  # マルチモードがオフなら、クリックしたbookがbookIdとなる
                        print("bookId", bookId)
                        for j in bookId:

                            book = j
                            print("seeing book is", book)
                            wb, ws = reading_file(file[book])

                            # 個別にdey_intervalを変えたいというとき
                            if book == 3:  # 訓読み
                                day_interval = [-1, 2, 5, 11, 20]

                            # 条件を通過した問題を、compb_list2に入れる
                            point_check()
                            # compリストのソート 日付降順（古いものから出す）
                            for a in range(len(compb_list2)):
                                a_banme = compb_list2[a]
                                a_banme = sorted(a_banme, key=lambda x: x[0], reverse=True)
                                compb_list2[a] = a_banme

                            # マルチ用にcompb_multiに引き継ぐ
                            compb_multi.append([book, compb_list2])

                        '''
                        book=i
                        wb, ws = reading_file(file[book])

                        #個別にdey_intervalを変えたいというとき
                        if book==3:#訓読み
                            day_interval = [-1, 2, 5, 11, 20]

                        #条件を通過した問題を、compb_list2に入れる
                        point_check()

                        # compリストのソート 日付降順（古いものから出す）
                        for a in range(len(compb_list2)):
                            a_banme = compb_list2[a]
                            a_banme = sorted(a_banme, key=lambda x: x[0], reverse=True)
                            compb_list2[a] = a_banme

                        # 統計データ閲覧用
                        toukei_etsuran = False  # Trueにすると見れます
                        if toukei_etsuran:
                            for a in range(len(compb_list3)):
                                print("###################", a, "点####################", day_interval[a], "日以上を出題")
                                a_banme = compb_list3[a]
                                a_banme = sorted(a_banme, key=lambda x: x[0], reverse=True)
                                compb_list3[a] = a_banme
                                day_change = -1
                                for b in a_banme:
                                    shutudai_ok = ""
                                    if day_change != b[0]:  # 日付ごとに改行する
                                        if (int(b[0]) >= int(day_interval[a])):
                                            shutudai_ok = "出題範囲内"
                                        else:
                                            shutudai_ok = ""
                                        print()
                                        print("###", b[0], "日　", shutudai_ok)

                                    md_name = ws.cell(start_r[book] + b[1], start_c[book] + c).value
                                    print("[", b[0], "日 ", b[1], " ", md_name, "]", sep="", end=" ")
                                    day_change = b[0]
                                print()
                        '''

                        if mode2 == 0:  # 通常モードで読み込み###現在使用していません
                            for ck in range(mondai_volume[book]):
                                pass
                                # mondai_su = n_check2(ck, mondai_su)
                            if mondai_su == 0:
                                mode=2
                        elif mode2 == 1:  # 100問耐久で読み込み
                            # 1セクション当たりの問題数(book別)
                            shutudai_p_point = sectionwise[book]
                            print(compb_list2)
                            for a in range(len(compb_list2)):  # size5=0,1,2,3,4
                                for b in range(len(compb_list2[a])):
                                    mondai_su = n_check3(compb_list2[a][b][1], mondai_su, book=book)
                                    if type(shutudai_p_point) == int:
                                        if b == shutudai_p_point:  # セクション毎に同じ問題数(int型)
                                            '''
                                            shutudai_p_pointは現在全てlistで管理しているためこの段落は不要
                                            '''
                                            break
                                    else:
                                        if b == shutudai_p_point[a]:  # セクション毎に異なる問題数(list型)
                                            break

                        elif mode2 in [2, 3]:  # 問題範囲選択アタックモードで読み込み
                            if mode2 == 2:  # アタックモード（番号選択式）
                                if zero_limited == False:  # ques_topからques_bottomまでを集める
                                    # 該当番号+1=問題番号　例:top=0 bottom=4 なら1,2,3,4,5
                                    st_posi = 1
                                    ed_posi = mondai_volume[book]
                                    # メッセージst-ed(A,B)に値が入力されている
                                    if message[2] != []:
                                        st_posi = message[2][0]
                                        ed_posi = message[2][1]
                                    # 問題番号-1(0からはじまるため)-patch_minus
                                    ques_top = st_posi - 1 - patch_minus[book]
                                    ques_bottom = ed_posi - 1 - patch_minus[book]
                                    under_mondai = 5  # この正当数以下を出題
                                    for ques in range(ques_top, ques_bottom + 1):
                                        mondai_su = n_check3(ques, mondai_su, book=book, under_mondai=under_mondai)

                                else:  # 累積0問のみを集める
                                    for b in range(len(compb_list2[0])):
                                        mondai_su = n_check3(compb_list2[0][b][1], mondai_su, book=book)
                            elif mode2 == 3:  # アタックモード（0問周回式）
                                for b in range(len(compb_multi)):
                                    book = compb_multi[b][0]
                                    mlist = compb_multi[b][1]
                                    wb, ws = reading_file(file[book])
                                    cnt_bysection = 0
                                    for b2 in range(len(mlist[0])):
                                        # d0=1のとき、未着手の問題には手を付けない(n_check3側の処理)
                                        mondai_su = n_check3(mlist[0][b2][1], mondai_su, book=book)
                                        cnt_bysection += 1
                                        # d0=0のとき、問題数を各sectionwiseの0問正解ぶんのみ収集する
                                        if message[4] != None:
                                            if message[4] == [0]:
                                                if cnt_bysection == sectionwise[book][0] + 1:
                                                    break
                                print(letter)

                            repeat_list = [0] * mondai_su

                            # cycleモード
                            if message[5] == [0]:
                                # 初期化
                                cycleList = cycle_mode_initialize()

                                # 出題決定
                                cyclePinSub = -1
                                cycle_question_skip()

                                # 次の問題の問題番号(m_num)
                                m_num = cycleList[cyclePin][cyclePinSub]

                        # 今回の問題一覧
                        print(mondai_su)
                        for c_ in range(len(letter)):
                            print(c_, letter[c_][0], letter[c_][1], letter[c_][6], letter[c_][8])

                if butt_100tokkun.collidepoint(event.pos):
                    mode2 += 1
                    if mode2==3:
                        zero_limited= not (zero_limited)  # 0問問題　真偽を反転

                    if mode2 == 4:
                        mode2 = 1

                if butt_0limited.collidepoint(event.pos):  #
                    zero_limited = not (zero_limited)  # 真偽を反転


            elif mode == 1:
                pass


        # キーダウンイベント
        if event.type == pygame.KEYDOWN:
            # イベントボックスのテキスト入力内容を受け取る
            if ipbox_active:
                if event.key == pygame.K_BACKSPACE:
                    ipbox_text = ipbox_text[:-1]
                else:
                    ipbox_text += event.unicode
        # キーアップイベント
        if event.type == KEYUP:
            if mode == 1:
                # キー入力（離されたら応答)
                if event.key == K_RETURN or event.key == K_z:
                    steat += 1
                elif event.key == K_BACKSPACE or event.key == K_a:
                    steat += 1
                    wrong_key = True
                else:
                    steat += 1
                    throug_key = True

                if steat % 3 == 1:
                    if letter[m_num][9] in [1, 3, 5, 6]:
                        # 上記のモードの時に、steat=0から2へ行く(1はスキップする)
                        steat += 1
                elif steat % 3 == 2:
                    pass
                else:
                    point = letter[m_num][6]
                    point = 0 if point == None else int(point)

                    if mode2 == 1:  # 100問モード
                        tmp_minus = patch_minus[book]
                        # スルー状態
                        if throug_key == True:
                            pass
                        # 間違えた状態
                        elif wrong_key == True:
                            ws.cell(row=start_r[book] + int(letter[m_num][0]) - 1 - tmp_minus,
                                    column=start_c[book] + c + q_type[book][4]).value = 0
                            point_volume[point] -= 1
                            point_volume[0] += 1
                            # 日付消去
                            ws.cell(row=start_r[book] + int(letter[m_num][0]) - 1 - tmp_minus,
                                    column=start_c[book] + c + q_type[book][4] + 1).value = ""
                        # 正解の状態
                        else:
                            # 得点の加算
                            ws.cell(row=start_r[book] + int(letter[m_num][0]) - 1 - tmp_minus,
                                    column=start_c[book] + c + q_type[book][4]).value = point + 1
                            # 最高得点の更新
                            past_best_p = letter[m_num][7] if letter[m_num][
                                                                  7] != None else 0  # 最高得点はNoneとして受け取る場合があるため、0に変換する
                            best_p = max(point + 1, past_best_p)  # Noneだと、ここで異変が起こる
                            ws.cell(row=start_r[book] + int(letter[m_num][0]) - 1 - tmp_minus,
                                    column=start_c[book] + c + q_type[book][4] + 2).value = best_p
                            # ポイントボリュームの更新
                            point_volume[point] -= 1
                            if point + 1 > 5:
                                point_volume[5] += 1  # ポイントが6になった場合
                            else:
                                point_volume[point + 1] += 1

                            # 日付入力
                            ws.cell(row=start_r[book] + int(letter[m_num][0]) - 1 - tmp_minus,
                                    column=start_c[book] + c + q_type[book][4] + 1).value = play_time
                            print(int(letter[m_num][0]), q_type[book][4])

                        cumul += 1
                        m_num += 1
                        # 全ての問題を使い切った
                        if m_num == mondai_su:
                            wb.save(file[book])
                            wb.close()
                            mode=2


                    elif mode2 == 2 or mode2 == 3:  # アタックモード
                        # スルー状態 間違えた状態
                        if throug_key == True or wrong_key == True:
                            pass
                        # 正解の状態
                        else:
                            repeat_list[m_num] = 1
                            repeat_1 += 1
                            seikai_su += 1

                            # cyclemode
                            if message[5] == [0]:
                                cycleCorrectNum += 1

                        if repeat_1 == mondai_su:
                            exit()
                            mode=2


                        # 問題番号を進める
                        if message[5] != [0]:
                            # repeat_list[m_num]が0（まだ正答していない）ようなm_numまで進める
                            while True:
                                m_num += 1
                                if m_num == mondai_su:
                                    m_num = 0
                                if repeat_list[m_num] == 0:
                                    break

                        else:
                            # 出題決定
                            # cyclePinSubを進める
                            cycle_question_skip()  # cyclePinSubが配列を超えることがある

                            # サイクルの最後は判定を行い、基準正解率を超えていたらcyclePinを一つ進める
                            if len(cycleList[cyclePin]) == cyclePinSub:
                                if cycleCorrectNum / len(cycleList[cyclePin]) >= cycleCorrectRatio:
                                    cyclePin += 1
                                    cyclePinSub = 0
                                    cycleCorrectNum = 0
                                else:
                                    cyclePinSub = -1
                                    cycle_question_skip()  # cyclePinSubがおそらく配列外へは到達しない

                            # 全体の最後である場合、初期化を行う
                            if len(cycleList) == cyclePin:
                                cycleList = cycle_mode_initialize()
                                print(cycleList)
                            # 次の問題の問題番号(m_num)の決定
                            m_num = cycleList[cyclePin][cyclePinSub]

    pygame.display.update()
    time.sleep(0.03)  # 約33フレーム　処理重防止のため

